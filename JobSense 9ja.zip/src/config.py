GROQ_API_KEY = "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"
MODEL = "openai/gpt-oss-120b"

APP_TITLE = "JobSense Nigeria"
APP_DESCRIPTION = "AI-powered job application assistant for Nigerian tech job seekers"
VERSION = "1.0.0"

EMBEDDING_MODEL = "all-MiniLM-L6-v2"
COLLECTION_NAME = "nigerian_companies"
RAG_RESULTS_COUNT = 3